//
//  AddLocationViewController.swift
//  On The Map
//
//  Created by Binyamin Alfassi on 20/09/2020.
//  Copyright © 2020 Binyamin Alfassi. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class AddLocationViewController: UIViewController, CLLocationManagerDelegate, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var navBarSearch: UINavigationItem!
        
    @IBOutlet weak var mediaLinkTextField: LoginTextField!
    
    let locationManager = CLLocationManager()
    var resultSearchController: UISearchController? = UISearchController()
    
    @IBOutlet weak var resultsTableView: UITableView!
    var matchingItems: [MKMapItem] = []
    
    let reuseId = "LocationSearchCellId"
    
    var searchBar: UISearchBar?
    
    var selectedLocation: MKMapItem? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        resultsTableView.delegate = self
        resultsTableView.dataSource = self
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        //locationManager.requestLocation()
//        let locationSearchTable = storyboard?.instantiateViewController(withIdentifier: "LocationSearchTable") as! LocationSearchTable
        resultSearchController!.searchResultsUpdater = self
        
        self.searchBar = resultSearchController!.searchBar
        searchBar!.sizeToFit()
        searchBar!.placeholder = "Search for an address"
        navBarSearch.titleView = resultSearchController?.searchBar
//        resultSearchController?.hidesNavigationBarDuringPresentation = false
//        resultSearchController?.obscuresBackgroundDuringPresentation = true
        definesPresentationContext = true

        mediaLinkTextField.backgroundColor = UIColor.clear
        
        
        let barButtonItem = UIBarButtonItem()
        barButtonItem.title = "CANCEL"
        barButtonItem.target = self
        barButtonItem.action = #selector(cancel)
        self.navigationItem.leftBarButtonItem = barButtonItem
    }

    @IBAction func FindLocationPushed(_ sender: Any) {
        guard let locationSelected = self.selectedLocation else {
            self.ShowFailure(message: "Address is not selected")
            return
        }
        guard AppUtilities.verifyUrl(mediaLinkTextField.text) else {
            ShowFailure(message: "Media URL is not valid")
            return
        }
        let seeOnMapVC =  storyboard?.instantiateViewController(withIdentifier: "SeeInMapVC") as! AddLocationMapVC
        seeOnMapVC.selectedLocation = locationSelected
        seeOnMapVC.selectedMediaUrl = mediaLinkTextField.text
        navigationController?.pushViewController(seeOnMapVC, animated: true)
//        present(seeOnMapVC, animated: true, completion: nil)
//        performSegue(withIdentifier: "SeeInMapSegue", sender: nil)
        
    }
    
    @objc func cancel() {
        dismiss(animated: true, completion: nil)
    }
    
    func ShowFailure(message: String) {
        let alertVC = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    
}



extension AddLocationViewController: UISearchResultsUpdating {
    
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBarText = searchController.searchBar.text
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchBarText
//        request.region = res.region
        let search = MKLocalSearch(request: request)
        search.start { (response, error) in
            guard let response = response else { print(error!)
                return
            }
            self.matchingItems = response.mapItems
            self.resultsTableView.reloadData()
        }
    }
}

extension AddLocationViewController {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.matchingItems.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseId, for: indexPath)

        // Configure the cell...
        let selectedItem = matchingItems[indexPath.row].placemark.title
        cell.textLabel?.text = selectedItem
        cell.detailTextLabel?.text = ""

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let location = matchingItems[indexPath.row]
        searchBar?.text = location.placemark.title
        self.selectedLocation = location
    }
}

extension AddLocationViewController: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.selectedLocation = nil
    }
}
