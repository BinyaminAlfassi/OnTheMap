//
//  MapViewController.swift
//  On The Map
//
//  Created by Binyamin Alfassi on 19/09/2020.
//  Copyright © 2020 Binyamin Alfassi. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    
    
    var studentsLocationList: [StudentLocation] {return StudentsLocationsModel.studentsLocationList}
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //setNavigationButtons()
        AppUtilities.SetBarButtons(self, addFunc: #selector(addLocation), refreshFunc: #selector(getStudentsList))
        getStudentsList()
        mapView.delegate = self
//        mapView?.register(self, forAnnotationViewWithReuseIdentifier: MKMapViewDefaultAnnotationViewReuseIdentifier)
        mapView.addAnnotations(StudentsLocationsModel.studentsLocationAnnotations)
    }
    
    func setNavigationButtons() {
        let refreshButton = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(getStudentsList))
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addLocation))
        self.navigationItem.rightBarButtonItems = [addButton, refreshButton]
        self.navigationItem.leftBarButtonItem = UIBarButtonItem()
        self.navigationItem.leftBarButtonItem?.title = "LOGOUT"
    }
    
    @objc func getStudentsList() {
        UdacityClient.getStudentsLocation(completion: handleStudentsListResponse(studentsLocationList:error:))
    }
    
    func handleStudentsListResponse(studentsLocationList: [StudentLocation], error: Error?) {
        if let error = error {
            print(error)
        } else {
            StudentsLocationsModel.updateStudentsLocationList(newList: studentsLocationList)
//            StudentsLocationsModel.studentsLocationList = studentsLocationList
        }
    }

    @objc func addLocation() {

    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId, for: annotation) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        } else {
            pinView!.annotation = annotation
        }
        
        return pinView
    }

}

//class LocationView: MKMarkerAnnotationView {
//
//    override var annotation: MKAnnotation? {
//        willSet {
//            if let _ = newValue as? Location {
//                self.displayPriority = .required
//            }
//        }
//    }
//}
