//
//  AddLocationMapVC.swift
//  On The Map
//
//  Created by Binyamin Alfassi on 20/09/2020.
//  Copyright © 2020 Binyamin Alfassi. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class AddLocationMapVC: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    var selectedLocation: MKMapItem?
    var selectedMediaUrl: String?
    
    let locationManager = CLLocationManager()
    var resultSearchController: UISearchController? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        placePin()
        zoomMap()
        // Do any additional setup after loading the view.
    }
    
    func zoomMap(){
        let coordinate = (self.selectedLocation?.placemark.coordinate)!
        let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        mapView.setRegion(region, animated: true)
    }
    
    func placePin() {
        let placemark = self.selectedLocation!.placemark as MKPlacemark
        mapView.addAnnotation(placemark)
    }

    @IBAction func finishTapped(_ sender: Any) {
        let placemark = self.selectedLocation!.placemark as MKPlacemark
        UdacityClient.postStudentLocation(studentLocation: placemark, mediaURL: self.selectedMediaUrl!, completion: handlePostSatudentLocation(success:error:))
    }
    
    func handlePostSatudentLocation(success: Bool, error: Error?) {
        if success {
            dismiss(animated: true, completion: nil)
        } else {
            ShowFailure(message: "Something went wrong")
        }
    }
    func ShowFailure(message: String) {
            let alertVC = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertVC, animated: true, completion: nil)
        }
}

